# Omega × ASI — fifteen module talks

15 standalone talks; 12 editable slides each. Start with all-modules.pdf or choose a module below.

Every deck includes responsibility, scope, dependencies, why it matters, measurements/benchmark gaps, invariants, current state and proposed future directions.

No new performance or integration tests were executed for this presentation series. Existing observations and contract bounds are labelled separately from proposed experiments.

| Module | PDF | PowerPoint | Notes |
|---|---|---|---|
| DA storage | [PDF](01-da-storage/slides.pdf) | [PowerPoint](01-da-storage/slides.pptx) | [Notes](01-da-storage/speaker-notes.md) |
| AtomStorage · C0 | [PDF](02-atom-storage/slides.pdf) | [PowerPoint](02-atom-storage/slides.pptx) | [Notes](02-atom-storage/speaker-notes.md) |
| Relations | [PDF](03-relations/slides.pdf) | [PowerPoint](03-relations/slides.pptx) | [Notes](03-relations/speaker-notes.md) |
| Search projection | [PDF](04-search/slides.pdf) | [PowerPoint](04-search/slides.pptx) | [Notes](04-search/speaker-notes.md) |
| EpisodicMemory · C1 | [PDF](05-episodic-memory/slides.pdf) | [PowerPoint](05-episodic-memory/slides.pptx) | [Notes](05-episodic-memory/speaker-notes.md) |
| BeliefRevision · C2 | [PDF](06-belief-revision/slides.pdf) | [PowerPoint](06-belief-revision/slides.pptx) | [Notes](06-belief-revision/speaker-notes.md) |
| PLNKernel | [PDF](07-pln-kernel/slides.pdf) | [PowerPoint](07-pln-kernel/slides.pptx) | [Notes](07-pln-kernel/speaker-notes.md) |
| Attention · C3 | [PDF](08-attention/slides.pdf) | [PowerPoint](08-attention/slides.pptx) | [Notes](08-attention/speaker-notes.md) |
| InferenceControl · C4 | [PDF](09-inference-control/slides.pdf) | [PowerPoint](09-inference-control/slides.pptx) | [Notes](09-inference-control/speaker-notes.md) |
| Agent messaging | [PDF](10-messaging/slides.pdf) | [PowerPoint](10-messaging/slides.pptx) | [Notes](10-messaging/speaker-notes.md) |
| Delegated execution | [PDF](11-execution/slides.pdf) | [PowerPoint](11-execution/slides.pptx) | [Notes](11-execution/speaker-notes.md) |
| Module registry | [PDF](12-registry/slides.pdf) | [PowerPoint](12-registry/slides.pptx) | [Notes](12-registry/speaker-notes.md) |
| Compatibility resolver | [PDF](13-resolver/slides.pdf) | [PowerPoint](13-resolver/slides.pptx) | [Notes](13-resolver/speaker-notes.md) |
| ConsensusFinality | [PDF](14-consensus-finality/slides.pdf) | [PowerPoint](14-consensus-finality/slides.pptx) | [Notes](14-consensus-finality/speaker-notes.md) |
| Authorization | [PDF](15-authorization/slides.pdf) | [PowerPoint](15-authorization/slides.pptx) | [Notes](15-authorization/speaker-notes.md) |

[All talks](all-modules.pdf). Install [DejaVu fonts](fonts/) for faithful editing; [license](fonts/LICENSE.txt).

Source snippets in source/ are editorial references. Rebuild in the fusion-module-interfaces repository, which supplies shared renderer primitives, fonts and evidence inputs.

Source snapshot: 494df69a1ac401c3d3b2cf79dbfde07f74b5e277. Tested runtime: bfb0ec8856c932dc2bcbc05b8949c957da8d72cd.

Speaker-note citations link directly to that immutable repository snapshot.
